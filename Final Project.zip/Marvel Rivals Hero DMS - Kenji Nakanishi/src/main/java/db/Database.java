package db;

import java.sql.*;

/**
 * Allow connection to the hero database
 * <p>
 *  Contains the configuration of the database using jdbcUrl while using additional methods
 *  to connect and close resources; this is a static utility class.
 * </p>
 *
 * <p> <strong>Responsibilities: </strong></p>
 * <ul>
 *     <li>Allow JDBC connection and save the URL used alongside the system</li>
 *     <li>Return new {@link Connection} to SQLite database</li>
 *     <li>It gives the closeQuietly to ensure safe open and closure of the db. properly handling exceptions. </li>
 *     <li>Supported file type: .db</li>
 * </ul>
 *
 * <p>The Database class is used by {@code JdbcHeroRepository} to use its actions implemented</p>
 *
 * @author Kenji Nakanishi
 * @since Phase 4
 */

public final class Database {
    /**The JDBC URL for the SQLite .db file */
    private static String url;
    /**Shared connection for the application */
    private static Connection CONN;
    /**If database schema has been initialized */
    private static volatile boolean initialized  = false;

    /**Private constructor that prevent instantiation, so it starts to false */
    private Database() {}

    /**
     * It sets the JDBC URL for the database connection;
     * <p>
     *     By using this method, we reset the connection and close any existing session.
     * </p>
     *
     * @param jdbcUrl is the JDBC URL("example, heroes.db")
     */
    public static synchronized void setUrl (String jdbcUrl) {
        url =jdbcUrl;
        initialized  = false;
        closeQuietly();
    }

    /**
     *
     * It will open and ensure an active connection to SQLite db. and if no connection exists or closed connection it will create a new connection.
     * <p>
     *     This method is using:
     * </p>
     *
     * <ul>
     *     <li><strong>Write ahead logging mode</strong> which reduces miss of choosing wrong file</li>
     *     <li> <strong>Foreign Key constraints</strong> To link specific fields where it needs to </li>
     * </ul>
     * 
     * @return a valid {@link Connection} to the SQLite db.
     * @throws SQLException if error occurs
     * @throws IllegalStateException if {@link #setUrl(String)} cannot be called
     * 
     */
    public static synchronized Connection getConnection() throws SQLException {
        if (url == null || url.isBlank()) {
            throw new IllegalStateException("Database URL is not set!");
        }
        if(CONN == null || CONN.isClosed()) {
        CONN = DriverManager.getConnection(url);
        try (Statement st = CONN.createStatement()) {
            st.execute("Pragma journal_mode=WAL;");
            st.execute("PRAGMA foreign_keys=ON;");
             }
        }
        ensureSchema(CONN);
        return CONN;
    }

    /**
     * Make sure the required database example heroes.db exists
     * <ul>
     *     <li>The {@code heroes} table</li>
     *     <li>Data integrity index of the {@code id} column</li>
     * </ul>
     *
     * This ensureSchema is creating one time during the application opening
     * @param c the live db connection
     * @throws RuntimeException if creation fails
     */

    private static synchronized void ensureSchema(Connection c)  {
        if(initialized) return;
        String createHeroes ="""
                CREATE TABLE IF NOT EXISTS heroes (
                    id          TEXT PRIMARY KEY,
                    name        TEXT NOT NULL,
                    hp          INTEGER,
                    move        INTEGER,
                    ult         INTEGER,
                    role        TEXT,
                    win_rate    REAL
                    );
            """;
            String uniq = """
                    CREATE UNIQUE INDEX IF NOT EXISTS ux_heroes_id ON heroes(id);
                """;
                try {
                    boolean oldAuto = c.getAutoCommit();
                    c.setAutoCommit(false);
                    try (Statement st = c.createStatement()) {
                        st.execute(createHeroes);
                        st.execute(uniq);
                    }
                    c.commit();
                    c.setAutoCommit(oldAuto);
                    initialized = true;
        } catch (SQLException e) {
            try { c.rollback(); } catch (Exception ignore) {}
                    throw new RuntimeException("Schema init failed"+ e.getMessage(), e);
        }
    }
    /**
     * Terminate connection of the opened database while ignoring exceptions if any.
     * <p> This method is called when existing the app so it can be closed the shared connection safely.</p>
     */
    public static synchronized void closeQuietly() {
        if (CONN != null){
            try { CONN.close(); } catch (Exception ignore) {}
            CONN = null;
        }
    }
}
