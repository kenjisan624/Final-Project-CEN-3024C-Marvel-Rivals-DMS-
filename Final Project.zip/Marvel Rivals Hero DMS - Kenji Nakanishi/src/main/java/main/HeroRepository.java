package main;

import java.util.List;

/**
 * Interface repository that defines the CRUD methods to manage {@link Hero} objects in the Marvel Rivals DMS.
 *
 * <p>By implementing this interface, we can store heroes in forms of:</p>
 *
 * <ul>
 *     <li>In memory collections (see {@code InMemoryHeroRepository}) </li>
 *     <li>SQLite database storage (see {@code JdbcHeroRepository}) </li>
 * </ul>
 *
 * <p>
 *    This performs as the data access layer in the application organization
 *    allowing the service layer named ({@link HeroFunctionalities}) interacting with the
 *    heroes data without caring about how data is managed and stored.
 * </p>
 *
 * @author Kenji Nakanishi
 * @since Phase 1
 *
 */
public interface HeroRepository {

    /**
     * Implementation can be done after ensuring that the hero IDs are unique and made sure
     * fields are correct before saving.
     *
     * @param hero the hero to be saved
     * @return {@code true} when save was success.
     *          {@code false} when not saved
     */
    boolean save(Hero hero);


    /**
     * Retrieves a hero from the repository using the ID; for the purpose of the DMS, we did not implemented
     * this function.
     * @param id the ID of the hero to be retrieved.
     * @return the matched {@link Hero} or {@code null} if not found.
     */

    Hero findById(String id);
    /**
     * Retrieves all the heroes available in the repository
     * @return a list of all {@link Hero} objects
     */
    List<Hero> findAll();

    /**
     *  This updates an existing hero from the repository.
     *
     *  <p>This can be used only if the hero exists with the specified hero ID </p>
     * @param hero the hero containing updated values
     * @return {@code true} if the hero update was successful
     *          {@code false} when not completed
     */
    boolean update(Hero hero);

    /**
     * Removes a hero from the repository basing on its ID
     *
     * @param id the ID of the hero to be deleted
     * @return {@code true} when the deletion has been completed
     *          {@code false} if the hero does not exist or removal failed.
     */
    boolean deleteById(String id);

    /**
     * Verify if the given ID exists in the current repository
     *
     * @param id to check the ID of the character
     * @return {@code true} if a match has been found
     *          {@code false} if not
     */
    boolean existsById(String id);
}
