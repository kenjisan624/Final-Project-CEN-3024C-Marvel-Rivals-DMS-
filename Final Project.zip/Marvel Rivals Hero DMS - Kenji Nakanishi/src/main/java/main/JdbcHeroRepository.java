package main;

import db.Database;

import java.sql.*;
import java.util.ArrayList;
import java.util.*;

/**
 * Hold actions that will be performed into the database, implements HeroRepository interface to allow
 * CRUD operation and write them down on the .db
 */
public class JdbcHeroRepository implements HeroRepository {
    /**
     * It creates a new {@code JdbcHeroRepository} instance using the default provided by
     * {@link db.Database} utility class.
     *
     * <p>This performs the CRUD operation for the SQLite database using the JDBC, connecting operations
     *  and ensuring that GUI and backend services are up. </p>
     */
    public JdbcHeroRepository() {

    }

    // Connects with the database and perform the INSERT INTO operation
    @Override
    public boolean save(Hero h) {
        final String sql = """
                INSERT INTO heroes (id, name, hp, move, ult, role, win_rate)
                VALUES (?, ?, ?, ?, ?, ?, ?)
        """;
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            bind(ps, h);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            System.err.println("Database error message" + e.getMessage());
            return false;
        }
    }
    // This method try to find the desired hero by its ID, even though is not directly implemented
    // in the GUI for the user to look a specific hero, this supports the CRUD operation by
    // identifying duplicated values or upgrade functionalities that can be added later on
    @Override
    public Hero findById(String id) {
        final String sql = "SELECT id, name, hp, move, ult, role, win_rate FROM heroes WHERE id = ?";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // This method will fetch heroes data and connects to the database to later
    // map the heroes, and with the refreshTable() it will display in the GUI heroes
    @Override
    public List<Hero> findAll() {
        final String sql = "SELECT id, name, hp, move, ult, role, win_rate FROM heroes ORDER BY id";
        List<Hero> out = new ArrayList<>();
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) out.add(map(rs));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return out;
    }

    // It provides to the user the ability to select the hero, and that id will be
    // updated or replaced with the new values, so we can obtain the new hero details after confirmation
    @Override
    public boolean update(Hero h) {
        final String sql = """
            UPDATE heroes SET name=?, hp=?, move=?, ult=?, role=?, win_rate=?
            WHERE id = ?
        """;
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, h.getHeroName());
            ps.setInt(2, h.getHealthPoint());
            ps.setInt(3, h.getMovementSpeed());
            ps.setInt(4, h.getUltDamage());
            ps.setString(5, h.getHeroRole());
            ps.setDouble(6, h.getWinRate());
            ps.setString(7, h.getIdentityHeroID());
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    //Linked to remove hero button in the GUI, it connects to the db and remove the hero after confirmation
    @Override
    public boolean deleteById(String id) {
        final String sql = "DELETE FROM heroes WHERE id =?";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, id);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // Prevents having multiple same Hero Identity ID
    @Override
    public boolean existsById(String id) {
        final String sql = "SELECT 1 FROM heroes WHERE id = ?";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // This bind will assign value on the objects called hero so SQL will recognise them
    //  ? -> will be assigned with each value
    private static void bind(PreparedStatement ps, Hero h) throws SQLException {
        ps.setString(1, h.getIdentityHeroID());
        ps.setString(2, h.getHeroName());
        ps.setInt(3, h.getHealthPoint());
        ps.setInt(4, h.getMovementSpeed());
        ps.setInt(5, h.getUltDamage());
        ps.setString(6, h.getHeroRole());
        ps.setObject(7, h.getWinRate());
    }

    //this do the opposite, from SQL database data to Hero object so Java can recognise it
    private static Hero map(ResultSet rs) throws SQLException {
        String id = rs.getString("id");
        String name = rs.getString("name");
        int hp = rs.getInt("hp");
        int move = rs.getInt("move");
        int ult = rs.getInt("ult");
        String role = rs.getString("role");
        Double wr = (Double) rs.getObject("win_rate");

        return new Hero(id, name, hp, move, ult, role, wr);
    }
}