/**
 *  * Professor:  Doctor Lisa Macon
 *  * Name: Kenji Nakanishi
 *  * Course: CEN 3024C - Software Development-I CRN:14877
 *  *
 *  * Purpose of the assignment: After GUI + Database added; the documentation such as valuable information.
 *  * will be added, for the Module 11, Javadoc API comments must be used in the IntelliJ project.
 *  * This final portion will be dedicated to explain classes, constructors, and interfaces, what does it do, how does it connect,
 *  * and relationships that hold between them.
 */


package ui;
import main.*;
import ui.DatabaseConnectionDialog;

import com.formdev.flatlaf.FlatDarkLaf;
import javax.swing.*;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.event.*;
import java.awt.*;
import java.net.URL;
import java.nio.file.Path;
/**
 *
 *
 *
 *  <h2> MainFrame.java - Marvel Rivals Hero Database Management System (DMS) </h2>
 *
 *<p>This is the class that will implement the User Interface; being able to
 * cast the layout with styling, dialog of the user input, and connecting to the JDBC SQLite repository printed to the user screen
 * . It also makes CRUD + customer methods operation (PDF report generation) possible by showing the stored values with its database information while validates
 * correct formatting and input.</p>
 *
 * <p><strong>Responsibilities: </strong></p>
 *
 * <ul>
 *     <li>Look and feel inspired on the original Marvel Rivals Game Season 1 </li>
 *     <li>Its organizes all the GUI dividing by left panel and right JTable</li>
 *     <li>Connects with SQLite database via {@link main.JdbcHeroRepository} </li>
 *     <li>Displays to the user heroes information using {@link javax.swing.JTable} with {@link javax.swing.table.DefaultTableModel}</li>
 *     <li>Launches required CRUD operations: add, update, remove, and custom method report on PDF format</li>
 *     <li>Safe save and exit implementation throwing exception and catching exception</li>
 * </ul>
 *
 * <p> GUI opens right after user have selected the SQLite file <code>.db</code>,
 * later user will be able to see the customized buttons labeled with the action its performs.
 * Since the transition of console based app to the GUI, the database only accepts .db format</p>
 *
 * @author Kenji Nakanishi
 * @since Phase 4
 *
 */
@SuppressWarnings({"FieldCanBeLocal","unused"})
public class MainFrame extends JFrame {

    private JPanel mainPanel;
    private JPanel leftPanel;
    private JPanel rightPanel;
    private JButton btnAddHero;
    private JButton btnUpdateHero;
    private JButton btnRemoveHero;
    private JButton btnImport;
    private JButton btnGeneratePDF;
    private JButton btnExit;
    private JTable heroTable;
    private final JLabel statusBar;
    private Path dbPath;
    private final DefaultTableModel heroModel;
    private  HeroFunctionalities heroFunctionalities;
    private HeroRepository repo;
    private boolean dirty = false;
    /**
     * Applied effect and style on the {@link GradientButtonUI} to give smoother appearance for the user.
     * Inspired by Marvel Rivals Season 1 designs.
     * @param b the button to the skin
     */
    private void skinButton(AbstractButton b) {
        b.setUI(new GradientButtonUI());
    }
    @SuppressWarnings("SameParameterValue")
    /** This will load the Marvel Rivals logo that is going to be used in the database.   */
    private static ImageIcon safeIcon(String path){
        URL url = MainFrame.class.getResource(path);
        return (url != null) ? new ImageIcon(url) : null;
    }
    /**
     * Constructor that contain application frame, initialize the GUI and its components.
     * configure style and load the Marvel Rivals JTable alongside database implementation
     *
     * <p> Implemented functions:</p>
     * <ul>
     *     <li>Load the logo to the screen</li>
     *     <li>Load the action listeners for the CRUD method and utility buttons</li>
     *     <li>Build the action buttons and Menu bar </li>
     *     <li>Prompt the user to load a .db file</li>
     *     <li>Start loading the file so the user can visualize them</li>
     * </ul>
     */
    public MainFrame() {
        FlatDarkLaf.setup();
        ImageIcon appIcon = safeIcon("/MR_Logo.png");
        if(appIcon != null) {
            setIconImage(appIcon.getImage());
        }
        UIManager.put("Component.arc", 12);
        UIManager.put("Button.arc", 16);
        UIManager.put("Table.showHorizontalLines", true);
        UIManager.put("Table.showVerticalLines", false);
        UIManager.put("Component.focusColor", Color.decode("#00B0FF"));
        UIManager.put("Button.startBackground", Color.decode("#D91A2A"));
        UIManager.put("Button.endBackground",   Color.decode("#D91A2A"));
        UIManager.put("Button.foreground", Color.WHITE);
        // Gaming Marvel Rivals colours for buttons
        Color MR_RED    = new Color(0xE2,0x36,0x36); // #e23636
        Color MR_GRAY   = new Color(0x50,0x4A,0x4A); // #504a4a
        Color MR_BLUE   = new Color(0x51,0x8C,0xCA); // #518cca

        UIManager.put("Component.focusColor", MR_BLUE);
        UIManager.put("Button.startBackground", MR_RED);
        UIManager.put("Button.endBackground",   MR_RED);
        UIManager.put("Button.foreground", Color.WHITE);

        UIManager.put("Table.selectionBackground", MR_BLUE);
        UIManager.put("Table.selectionForeground", Color.WHITE);
        UIManager.put("Table.gridColor", MR_GRAY);
        UIManager.put("Panel.background", new Color(32,32,32));   // nicer dark bg
        UIManager.put("Label.foreground", Color.WHITE);

        setTitle("Marvel Rivals Hero DMS");

        // Icon picture; small but can be used for user reference and also as left side picture
        ImageIcon rawIcon = safeIcon("/MR_Logo.png");
        if (rawIcon != null) {
            Image scaled = rawIcon.getImage().getScaledInstance(200, 100, Image.SCALE_SMOOTH);
            JLabel logoLabel = new JLabel(new ImageIcon(scaled));
            logoLabel.setHorizontalAlignment(SwingConstants.CENTER);
            logoLabel.setVerticalAlignment(SwingConstants.CENTER);
            logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            logoLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));

            leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
            leftPanel.add(logoLabel);
            leftPanel.add(Box.createVerticalStrut(10));
        } else {
            leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
            leftPanel.add(Box.createVerticalStrut(10));
        }

        // giving the buttons some space for better look
        leftPanel.add(Box.createVerticalStrut(10));
        leftPanel.add(btnAddHero);
        leftPanel.add(Box.createVerticalStrut(10));
        leftPanel.add(btnUpdateHero);
        leftPanel.add(Box.createVerticalStrut(10));
        leftPanel.add(btnRemoveHero);
        leftPanel.add(Box.createVerticalStrut(10));
        leftPanel.add(btnImport);
        leftPanel.add(Box.createVerticalStrut(10));
        leftPanel.add(btnGeneratePDF);
        leftPanel.add(Box.createVerticalStrut(10));
        leftPanel.add(btnExit);
        leftPanel.add(Box.createVerticalGlue());

        // the app size when hitting on run
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(1200, 600);
        setLocationRelativeTo(null);

        skinButton(btnAddHero);
        skinButton(btnUpdateHero);
        skinButton(btnRemoveHero);
        skinButton(btnImport);
        skinButton(btnGeneratePDF);
        skinButton(btnExit);

        for (Component comp : leftPanel.getComponents()) {
            if (comp instanceof JButton btn) {
                btn.setAlignmentX(Component.CENTER_ALIGNMENT);
                btn.setMaximumSize(new Dimension(200,50));
            }
        }
        String[] cols = {
                "Hero ID", "Name", "HP", "Movement Speed", "Ult Damage", "Role", "Win Rate"
        };
        heroModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) {   return false; }
            @Override public Class<?> getColumnClass(int col) {
                return switch (col) {
                    // Health Point, Movement Speed, and Ult Damage
                    case 2, 3, 4 -> Integer.class;
                    // Win Rate
                    case 6 -> Double.class;
                    // Hero ID, Name, and Role
                    default -> String.class;
                };
            }
        };
        heroTable.setModel(heroModel);
        heroTable.setAutoCreateRowSorter(true);
        heroTable.setRowHeight(22);
        heroTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        heroTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        heroTable.setRowSorter(new TableRowSorter<>(heroModel));
        // notice is very important to have a ScrollPane
        rightPanel.setLayout(new BorderLayout());
        rightPanel.removeAll();
        rightPanel.add(new JScrollPane(heroTable), BorderLayout.CENTER);

        // Added a Menu item section, not needed but nice to have it as well!
        // will prompt to save before exit
        JMenuBar mb = new JMenuBar();
        JMenu file = new JMenu("File");
        JMenuItem open = new JMenuItem("Open Database");
        JMenuItem exit = new JMenuItem("Exit");

        // The options for the user to connect or cancel and exits
        open.addActionListener(e -> reconnectToDatabase());
        exit.addActionListener(e -> doExit());

        // Top Menu
        file.add(open);
        file.addSeparator();
        file.add(exit);
        mb.add(file);
        setJMenuBar(mb);

        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { doExit(); }
        });

        btnAddHero.addActionListener(e -> {addHero(); });
        btnUpdateHero.addActionListener(e -> {updateHero();});
        btnRemoveHero.addActionListener(e -> {removeHero();});
        btnImport.addActionListener(e -> { importHeroes();});
        btnGeneratePDF.addActionListener(e -> generateReport());
        btnExit.addActionListener(e -> doExit());

        //This nice a nice indication message where the user can see clearly that the .db is connected!
        statusBar = new JLabel("Connected...!");
        statusBar.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
        JPanel root = new JPanel(new  BorderLayout());
        root.add(mainPanel, BorderLayout.CENTER);
        root.add(statusBar, BorderLayout.SOUTH);
        setContentPane(root);

        // Dialog that opens first so user can select the .db file
        DatabaseConnectionDialog dlg = new DatabaseConnectionDialog(this);
        dlg.setVisible(true);
        if (!dlg.isOk()) {
            dispose();
            System.exit(0);
            return;
        }
        this.repo = new JdbcHeroRepository();
        this.heroFunctionalities = new HeroFunctionalities(this.repo);
        refreshTable();
        setVisible(true);
    }
    /**
     * This will reload the hero data set on the database and populate the JTable model with current updated information
     * The refreshTable is called after each CRUD operation to keep consistent data on the GUI reflecting the most update state to the users.
     */
    private void refreshTable() {
        heroModel.setRowCount(0);
        java.util.List<Hero> heroes = repo.findAll();
        for (Hero h : heroes) {
            heroModel.addRow(new Object[]{
                    h.getIdentityHeroID(),
                    h.getHeroName(),
                    h.getHealthPoint(),
                    h.getMovementSpeed(),
                    h.getUltDamage(),
                    h.getHeroRole(),
                    h.getWinRate()
            });
        }
    }
    /**
     * Allow user to select a SQLite .db file, once opened the {@link JdbcHeroRepository} will create a new instance, then toast will be called to display
     * a text to the user to confirm success load!
     */
    private void reconnectToDatabase() {
        DatabaseConnectionDialog d = new DatabaseConnectionDialog(this);
        d.setVisible(true);
        if (!d.isOk()) return;

        this.repo = new JdbcHeroRepository();
        this.heroFunctionalities = new HeroFunctionalities(this.repo);
        refreshTable();

        dirty = false;
        toast("Connected to new database");
    }
    /**
     * Display message when information has been given.
     * @param msg the text to display
     */
    private void toast(String msg) {
        JOptionPane.showMessageDialog(this, msg);
    }
    /**
     * with {@link HeroForm} it creates a new hero dataset, and after user click on ok, the validation portion comes in to
     * double-check there is not repetitive IDs.
     *
     * <p> Indicates the problem when caught by displaying messages to the user</p>
     */
    private void addHero() {
        HeroForm form = new HeroForm(this, null);
        Hero hero = form.showDialog();
        if (hero == null) return;

        for (int i = 0; i < heroModel.getRowCount(); i++) {
            if (String.valueOf(heroModel.getValueAt(i,0)).equals(hero.getIdentityHeroID())) {
                toast("Duplicate Hero ID:" + hero.getIdentityHeroID());
                return;
            }
        }
        boolean ok = heroFunctionalities.addHero(hero);
        if (!ok)  { toast("Something went wrong!! Add failed..."); return; }
        refreshTable();
    }
    /**
     * After selection of the hero from the user, it opens a dialog filled out with the current hero information,
     * user will modify existing records and this is handled by {@link HeroForm}
     *
     * <p>Making sure: </p>
     * <ul>
     *     <li>A row is being selected by the user</li>
     *     <li>Duplicated IDs is illegal</li>
     *     <li>When finishing editing, validation will be conducted by GUI </li>
     *
     *     <p>When finished updating, JTable is refreshed.</p>
     * </ul>
     */
    private void updateHero() {
        int vr = heroTable.getSelectedRow();
        if (vr < 0) {
            toast("Selected a Marvel Rivals Hero in the table to UPDATE.");
            return;
        }
        Hero current = rowToHero(vr);
        HeroForm form = new HeroForm(this, current);
        Hero edited = form.showDialog();
        if (edited == null) return;
        if (!edited.getIdentityHeroID().equals(current.getIdentityHeroID())) {
            for (int i = 0; i < heroModel.getRowCount(); i++) {
                if (String.valueOf(heroModel.getValueAt(i, 0)).equals(edited.getIdentityHeroID())) {
                    toast("Existing ID: Another row already uses ID!!! " + edited.getIdentityHeroID());
                    return;
                }
            }
        }
        try {
            boolean ok = heroFunctionalities.updateMarvelHero(edited);
            if (!ok) {
                heroFunctionalities.removeMarvelHeroById(current.getIdentityHeroID());
                ok = heroFunctionalities.addHero(edited);
            }
            if (!ok) {
                toast("Something went wrong! Update failed....");
                return;
            }
            refreshTable();
            dirty = true;

        } catch(IllegalArgumentException ex){
            toast("Invalid data: " + ex.getMessage());
        } catch(Exception ex){
            toast("Error! " + ex.getMessage());
        }
    }
    /**
     * Remove the selected hero from the database after confirmation from the user.
     * It makes sure by showing a dialog with the hero information to double-check user is sure to delete that selected hero record..
     */
    private void removeHero() {
        int viewRow = heroTable.getSelectedRow();
        if (viewRow < 0) {
            toast("Select a Marvel Rivals Hero to REMOVE.");
            return;
        }
        int modelRow = heroTable.convertRowIndexToModel(viewRow);
        String id = String.valueOf(heroModel.getValueAt(modelRow, 0));
        int ok = JOptionPane.showConfirmDialog(
                this,
                "Remove hero " + id + "?",
                "Confirm",
                JOptionPane.YES_NO_OPTION
        );
        if (ok != JOptionPane.YES_OPTION) return;
        boolean removed = heroFunctionalities.removeMarvelHeroById(id);
        if (!removed) {
            toast("Something went wrong! Remove failed...");
            return;
        }
        refreshTable();
        dirty = true;
    }
    /**
     * User can select the external source of their .db file to implement on the current database,
     * this is going to be handled by {@link HeroFunctionalities#loadFromSavedFile(Path)}
     *
     * After the load, a dialog will show the imported and failed entries done.
     */
    private void importHeroes() {
        JFileChooser fc = new JFileChooser();
        if (fc.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return;

        Path path = fc.getSelectedFile().toPath();
        try {
            HeroFunctionalities.ImportResult r = heroFunctionalities.loadFromSavedFile(path);
            //repo.setCurrentFile(path);
            refreshTable();
            toast(r.toString());
        } catch (Exception ex) {
            toast("Something went wrong! Import failed... " + ex.getMessage());
        }
    }
    /**
     * Prompt user to enter a location on their devices to save the Win Rate % in PDF format.
     * PDF file creation will be done using {@link HeroFunctionalities#generateWinRateReport(Path)}
     * at the end, after successful creation of the file, it will open for the user.
     */
    private void generateReport() {
        try {
            JFileChooser fc = new JFileChooser();
            fc.setDialogTitle("Save Win Rate report");
            if(fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;

            Path out = fc.getSelectedFile().toPath();
            String name = out.getFileName().toString().toLowerCase();
            if (!name.endsWith(".pdf")) {
                out = out.resolveSibling(out.getFileName() + ".pdf");
            }
            heroFunctionalities.generateWinRateReport(out);
            try {Desktop.getDesktop().open(out.toFile()); } catch (Exception ignore) {}
            toast("PDF has been saved to:\n" + out.toAbsolutePath());
        } catch (Exception ex) {
            toast("Something went wrong. Generate report failed... " + ex.getMessage());
        }
    }
    /**  Close GUI and terminate the application.   */
    private void doExit() {
        dispose();
        System.exit(0);
    }
    /**
     * Shift JTable row viw to the index version on the {@link Hero} object, so visually organize it on the DMS for the user.
     *
     * @param viewRow is the index from the JTable view
     * @return a Hero object that represents the row on the data
     */
    private Hero rowToHero(int viewRow) {
        int r = heroTable.convertRowIndexToModel(viewRow);
        return new Hero(
                String.valueOf(heroModel.getValueAt(r, 0)),
                String.valueOf(heroModel.getValueAt(r, 1)),
                Integer.parseInt(String.valueOf(heroModel.getValueAt(r, 2))),
                Integer.parseInt(String.valueOf(heroModel.getValueAt(r, 3))),
                Integer.parseInt(String.valueOf(heroModel.getValueAt(r, 4))),
                String.valueOf(heroModel.getValueAt(r, 5)),
                Double.parseDouble(String.valueOf(heroModel.getValueAt(r, 6)))
        );
    }

    /**
     * <h3> HeroForm - this is used to add, edit heroes information</h3>
     *
     * <p> This will prompt the user the windows dialog to input information whether creating or
     * updating. It also validates the information that user is typing so if the values are not in the allowed range, it will not be accepted.
     * </p>
     *
     * <ul>
     *     <li>Arrange heroes when editing or adding them</li>
     *     <li>Validation within the GUI of the values Identity hero ID, Health Point, Movement Speed, Ult Damage, Win rate </li>
     *     <li>Role formatting with drop down menu to avoid long text input handled by {@link HeroFunctionalities#HeroRoleFormat(String)}</li>
     *     <li>When fully validated, return the values of the object to {@link Hero} to pass it to MainFrame</li>
     * </ul>
     */
    private static class HeroForm {
        private final JDialog dlg;
        private final JTextField tfId = new JTextField(4);
        private final JTextField tfName = new JTextField(22);
        private final JTextField tfHp = new JTextField(4);
        private final JTextField tfSpeed = new JTextField(2);
        private final JTextField tfUlt = new JTextField(5);
        private final JComboBox<String> cbRole =
                new JComboBox<>(new String[]{"DUELIST", "STRATEGIST", "VANGUARD"});
        private final JTextField tfWin = new JTextField(5);
        private Hero result = null;

        HeroForm(Frame owner, Hero preset) {
            dlg = new JDialog(owner, (preset == null ? "Add Hero" : "Update Hero"), true);

            JPanel p = new JPanel(new GridBagLayout());
            GridBagConstraints gc = new GridBagConstraints();
            // adding some padding !
            gc.insets = new Insets(6, 8, 6, 8);
            gc.fill = GridBagConstraints.HORIZONTAL;
            // this part will be shown on the add hero or update input window
            int r = 0;
            addRow(p, gc, r++, "Hero Identity ID (3-digits):", tfId);
            addRow(p, gc, r++, "Hero Name: (3 words)", tfName);
            addRow(p, gc, r++, "Health Point: (250~900)", tfHp);
            addRow(p, gc, r++, "Movement Speed: (6~9)", tfSpeed);
            addRow(p, gc, r++, "Ultimate Damage: (300~9999)", tfUlt);
            addRow(p, gc, r++, "Hero Role:", cbRole);
            addRow(p, gc, ++r, "Win Rate:(0.00~100)", tfWin);

            JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            JButton ok = new JButton("OK"), cancel = new JButton("Cancel");
            buttonsPanel.add(ok); buttonsPanel.add(cancel);

            dlg.getContentPane().add(p, BorderLayout.CENTER);
            dlg.getContentPane().add(buttonsPanel, BorderLayout.SOUTH);
            dlg.pack();
            dlg.setLocationRelativeTo(owner);

            if (preset != null) {
                tfId.setText(preset.getIdentityHeroID());
                tfName.setText(preset.getHeroName());
                tfHp.setText(String.valueOf(preset.getHealthPoint()));
                tfSpeed.setText(String.valueOf(preset.getMovementSpeed()));
                tfUlt.setText(String.valueOf(preset.getUltDamage()));
                cbRole.setSelectedItem(preset.getHeroRole().toUpperCase());
                tfWin.setText(String.valueOf(preset.getWinRate()));
            }
            ok.addActionListener(e -> {
                try {
                    String id = tfId.getText().trim();
                    String name = tfName.getText().trim().replaceAll("\\s+", " ");
                    int hp = Integer.parseInt(tfHp.getText().trim());
                    int speed = Integer.parseInt(tfSpeed.getText().trim());
                    int ult = Integer.parseInt(tfUlt.getText().trim());
                    String roleRaw = String.valueOf(cbRole.getSelectedItem());
                    String role = HeroFunctionalities.HeroRoleFormat(roleRaw);

                    if(role == null) {
                        JOptionPane.showMessageDialog(dlg, "Role must be Duelist, Strategist, or Vanguard.");
                        return;
                    }
                    double wr = Double.parseDouble(tfWin.getText().trim());
                    // simple GUI-side validation (your service will re-validate too)
                    if (!id.matches("\\d{3}") || name.isEmpty()
                            || hp < 250 || hp > 900
                            || speed < 6 || speed > 9
                            || ult < 300 || ult > 9999
                            || wr < 0 || wr > 100) {
                        JOptionPane.showMessageDialog(dlg, "Please fix invalid entries.");
                        return;
                    }
                    result = new Hero(id, name, hp, speed, ult, role, wr);
                    dlg.dispose();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dlg, "Please fix invalid entries.");
                }
            });
            cancel.addActionListener(e -> dlg.dispose());
        }
        /**
         * Utility method that put components on the current form
         * @param p the container of the panel
         * @param gc layout constraints
         * @param row the index of the row
         * @param label text for the label
         * @param field the input field component
         */
        private static void addRow(JPanel p, GridBagConstraints gc, int row, String label, JComponent field) {
            gc.gridx = 0; gc.gridy = row; gc.weightx = 0;
            p.add(new JLabel(label), gc);
            gc.gridx = 1; gc.gridy = row; gc.weightx = 1;
            p.add(field, gc);
        }
        /**
         * Display dialog and it blocks until closed
         * @return a constructed {@link Hero} if the user click OK once validation is passed,if canceled {@code null}.
         */
        Hero showDialog() { dlg.setVisible(true); return result; }
    }
    /**
     * Launches the application and creates the {@link MainFrame}
     * @param args is not used
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(MainFrame::new);
    }
}